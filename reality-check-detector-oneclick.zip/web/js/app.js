const fileInput = document.getElementById('file');
const dropzone = document.getElementById('dropzone');
const preview = document.getElementById('preview');
const analyzeBtn = document.getElementById('analyze');
const reportEl = document.getElementById('report');
const summaryEl = document.getElementById('summary');
const detailsEl = document.getElementById('details');
const downloadBtn = document.getElementById('download');
const loginPrompt = document.getElementById('loginPrompt');

let currentFile = null;

dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.style.opacity = 0.9; });
dropzone.addEventListener('dragleave', () => { dropzone.style.opacity = 1; });
dropzone.addEventListener('drop', e => { e.preventDefault(); dropzone.style.opacity = 1; const f = e.dataTransfer.files[0]; handleFile(f); });
fileInput.addEventListener('change', () => { handleFile(fileInput.files[0]); });

function handleFile(f){
  if(!f) return;
  currentFile = f;
  preview.innerHTML = '';
  if(f.type.startsWith('image/')){
    const img = document.createElement('img'); img.className='preview-img'; img.src = URL.createObjectURL(f); preview.appendChild(img);
  } else if(f.type.startsWith('video/')){
    const v = document.createElement('video'); v.className='preview-video'; v.controls=true; v.src = URL.createObjectURL(f); preview.appendChild(v);
  } else { preview.textContent = 'Unsupported file type'; }
  analyzeBtn.disabled = false;
  reportEl.classList.add('hidden');
}

function getToken(){ return localStorage.getItem('rc_token'); }
function requireLogin(){ if(!getToken()){ alert('Please login to submit.'); location.href='/login.html'; return false; } return true; }

analyzeBtn.addEventListener('click', async ()=>{
  if(!currentFile) return;
  if(!requireLogin()) return;
  analyzeBtn.disabled=true; analyzeBtn.textContent='Analyzing...';
  const fd=new FormData(); fd.append('file', currentFile);
  try{
    const res=await fetch('/api/analyze',{method:'POST',body:fd, headers: { 'Authorization': 'Bearer '+getToken() }});
    if(!res.ok){ const err=await res.json(); throw new Error(err.error || res.statusText); }
    const data=await res.json(); renderReport(data);
  }catch(e){ alert('Error: '+e.message); } finally { analyzeBtn.disabled=false; analyzeBtn.textContent='Analyze'; }
});

function renderReport(r){
  reportEl.classList.remove('hidden');
  summaryEl.innerHTML = `<strong>Verdict:</strong> ${r.verdict} — <strong>Score:</strong> ${r.score}%`;
  detailsEl.textContent = JSON.stringify(r.details, null, 2);
  const blob=new Blob([JSON.stringify(r,null,2)],{type:'application/json'});
  downloadBtn.href=URL.createObjectURL(blob);
  reportEl.scrollIntoView({behavior:'smooth'});
}

// login prompt handler
loginPrompt.addEventListener('click', ()=>{ location.href='/login.html'; });
